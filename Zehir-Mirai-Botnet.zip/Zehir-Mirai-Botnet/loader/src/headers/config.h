#pragma once

#define HTTP_SERVER "153.92.30.158"
#define HTTP_PORT 80

#define TFTP_SERVER "153.92.30.158"
